<div id="centermsg">
	<h1>SIG Web Meeting #3 - 5</h1>
	<h2>A short introduction to Server-side Development</h2>
	<p>On the contrary to the previous two weeks, this is certainly a better effort toward better design.</p>
</div>
<article>
	<header><h1>Steps to Follow:</h1></header>
	<ol>
		<li>Download this code!</li>
			<p>This code is available on the SIG-Web page. See the attachment section.</p>
		<li>Upload to your testing environment</li>
			<p>In order for server-side scripting to work, you must have a server parse the input. <br /> 
			I recommend you use your ACM/LUG account to test out your code. <br />
			In your home directory, just create a &ldquo;public_html&rdquo; folder in your home directory.<br />
			</p>
		<li>Implement some server-side scripting!</li>
			<p>More on this once everyone is done setting up... I'll start talking some more to explain...</p>
	</ol>
</article>
<article>
<h1>Results:</h1>
<?php if (isset($message)) { echo "<div class=\"alert\"><p>".$message."</p></div>";} ?>
			<?php 
			/* Select queries return a resultset */
			if ($result = $mysqli->query("SELECT ID, title FROM posts")) {
				$numresults = $result->num_rows;
		    	printf("<p>Our query returned %d rows.</p>\n", $numresults);
			}
			?>
			<br />
	<a href="add.php">Create</a>
	<br /><br />
	<table>
		<tr><th>ID</th><th>Title</th><th>Actions</th></tr>
		<?php
		if ($numresults == 0) {
			echo "<tr><td></td><td>No Entries found.</td><td>View | Edit | Delete</td></tr>";
		} else {
			while($obj = $result->fetch_object()){ 
				printf("<tr><td>%d</td><td>%s</td><td><a href=\"view.php?id=$obj->ID\" >View</a> | <a href=\"edit.php?id=$obj->ID\" >Edit</a> | <a href=\"delete.php?id=$obj->ID\" >Delete</a></td></tr>", $obj->ID, $obj->title);
			}

		}
		/* free result set */
		$result->close();
		?>
	</table>
</article>
