<?php
if (isset($_GET['id'])) {
if (!is_null($_GET['id'])) {
	/* Select queries return a resultset */
	if ($result = $mysqli->query("SELECT * FROM posts WHERE id = " . $_GET['id'])) {
		$obj = $result->fetch_object();
		$title = $obj->title;
		$body = $obj->body;
		$id = $obj->id;
		$result->close();
	}
}
}
?>
<div id="centermsg">
	<br /><br />
	<h1><?php if(isset($title)) {echo $title;}else {echo "Empty...";} ?></h1>
</div>
<article>
	<p><?php if(isset($body)) {echo $body;}else {echo "I have nothing to display.";} ?></p>
	<hr />
	<a href=".">Return to Home &raquo;</a>
</article>