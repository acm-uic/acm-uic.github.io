<?php
	error_reporting(E_ALL);
	ini_set('display_errors', '1');
	require_once("functions.php");
	require_once("header.php");
if (isset($_GET['id'])) {
if (!is_null($_GET['id'])) {
	/* Select queries return a resultset */
	if ($result = $mysqli->query("DELETE FROM posts WHERE id = " . $_GET['id'])) {
		$message = "You have deleted post #: " . $_GET['id'];
	}
}
}
	require_once("body.php");
	require_once("footer.php");