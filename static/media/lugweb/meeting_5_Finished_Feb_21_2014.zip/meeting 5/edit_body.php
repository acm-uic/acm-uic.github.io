<?php
if (isset($_GET['id'])) {
if (!is_null($_GET['id'])) {
	/* Select queries return a resultset */
	if ($result = $mysqli->query("SELECT * FROM posts WHERE id = " . $_GET['id'])) {
		$obj = $result->fetch_object();
		$count = $result->num_rows;
		$title = $obj->title;
		$body = $obj->body;
		$id = $obj->id;
		$result->close();
	}
}
}

if (isset($_POST['submit'])) {
	$result = $mysqli->query("UPDATE `posts` SET title = '".$_POST['title']."', body = '".$_POST['body']."' WHERE id = ".$_POST['id'].";");
}
?>
<article>
	<h1>Edit <?php if (isset($id) && $count == 1) {echo $id;} else {echo "Nothing...";} ?></h1>
	<form name="editsubmit" action="edit.php" method="post">
	Title: <input type="text" name="title" value="<?php if (isset($title)) {echo $title; } ?>"><br />
	Body: <br /><textarea name="body" rows="4" cols="50"><?php if (isset($body)) {echo $body; } ?></textarea><br />
	<input type="hidden" name="id" value="<?php echo $_GET['id']?>">
	<button name="submit">Submit!</button>
	</form> 
	<hr />
	<a href=".">Return to Home &raquo;</a>
</article>