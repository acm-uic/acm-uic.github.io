<?php
// Connecting, selecting database
//mysqli_connect("localhost", "my_user", "my_password", "world");
$mysqli = new mysqli("localhost", "testuser", "password", "sigwebtest");

/* check connection */
if ($mysqli->connect_errno) {
    printf("Connect failed: %s\n", $mysqli->connect_error);
    exit();
}


?>