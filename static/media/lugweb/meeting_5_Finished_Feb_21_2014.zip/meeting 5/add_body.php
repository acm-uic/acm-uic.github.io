<?php

if (isset($_POST['submit'])) {
	$result = $mysqli->query("INSERT INTO `posts` (title, body) VALUES ('".$_POST['title']."', '".$_POST['body']."')");
	$done = $result;
}
?>
<article>
	<h1>Add</h1>
	<?php if (isset($done)) { echo "<p>Successfully submitted!</p>";}?>
	<form name="editsubmit" action="add.php" method="post">
	<label for="title">Title: </label><input type="text" id="title" name="title"><br />
	<label for="body">Body: </label><br /><textarea name="body" id="body" rows="4" cols="50"></textarea><br />
	<button name="submit">Submit!</button>
	</form>
	<br /> 
	<hr />
	<a href=".">Return to Home &raquo;</a>
</article>