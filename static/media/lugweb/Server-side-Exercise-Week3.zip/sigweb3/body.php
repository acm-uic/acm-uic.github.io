<div id="centermsg">
	<h1>SIG Web Meeting #3</h1>
	<h2>A short introduction to Server-side Development</h2>
	<p>On the contrary to the previous two weeks, this is certainly a better effort toward better design.</p>
</div>
<article>
	<header><h1>Steps to Follow:</h1></header>
	<ol>
		<li>Download this code!</li>
			<p>This code is available on the SIG-Web page. See the attachment section.</p>
		<li>Upload to your testing environment</li>
			<p>In order for server-side scripting to work, you must have a server parse the input. <br /> 
			I recommend you use your ACM/LUG account to test out your code. <br />
			In your home directory, just create a &ldquo;public_html&rdquo; folder in your home directory.<br />
			</p>
		<li>Implement some server-side scripting!</li>
			<p>More on this once everyone is done setting up... I'll start talking some more to explain...</p>
	</ol>
</article>