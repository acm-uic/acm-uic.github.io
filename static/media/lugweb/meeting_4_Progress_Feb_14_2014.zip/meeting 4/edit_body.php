<?php
if(isset($_GET['id'])) {
	
	if ($result = $mysqli->query("SELECT * FROM posts WHERE id = " . $_GET['id'])) {
		$obj = $result->fetch_object();
		$id = $obj->id;
		$title = $obj->title;
		$body = $obj->body;
		$timestamp = $obj->timestamp;
		$result->close();
	}
}
?>

<?php 
if(isset($_POST['submit'])) {
	var_dump($_POST);
}
?>

<h1>Editing: <?php if(isset($title)){echo $title;} else {echo "Submitted.";} ?></h1>
<article>
<form name="editsubmit" action="edit.php" method="post">
Title:<input type="text" name="title" value="<?php echo $title; ?>"><br />
Body:<textarea name="body" rows="4" cols="50"><?php echo $body; ?></textarea><br />
<button name="submit">Submit!</button>

</form>
</article>
