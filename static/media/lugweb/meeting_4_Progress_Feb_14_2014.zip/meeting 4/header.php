<!DOCTYPE html>
<html>
	<head>
		<title>LUG | SIG-Web Meeting #3</title>
		<link href='//fonts.googleapis.com/css?family=Exo+2:600|Open+Sans' rel='stylesheet' type='text/css'>
		<link rel="stylesheet" type="text/css" href="assets/default.css">
	</head>
	<body>
	<header class="navbar" role="banner">
		<div class="container">
			<nav role="navigation">
				<ul>
					<li><a href="#">Add(CREATE)</a></li>
					<li><a href="#">Read(READ)</a></li>
					<li><a href="#">Edit(UPDATE)</a></li>
					<li><a href="#">Remove(DELETE)</a></li>
				</ul>
			</nav>
		</div>
	</header>
