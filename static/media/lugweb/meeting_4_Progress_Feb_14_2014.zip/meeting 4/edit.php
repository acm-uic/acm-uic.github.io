<?php
	error_reporting(E_ALL);
	ini_set('display_errors', '1');
	require_once("functions.php");
	require_once("header.php");
	require_once("edit_body.php");
	require_once("footer.php");
