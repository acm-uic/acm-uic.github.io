<?php
if(isset($_GET['id'])) {
	
	if ($result = $mysqli->query("SELECT * FROM posts WHERE id = " . $_GET['id'])) {
		$obj = $result->fetch_object();
		$id = $obj->id;
		$title = $obj->title;
		$body = $obj->body;
		$timestamp = $obj->timestamp;
		$result->close();
	}
}
?>


<div id="centermsg">
<h1><?php echo $title; ?></h1>
</div>
<article>
<p>
<?php // This is where the body of the post will go.
	echo $body;
?>
</p>
</article>
