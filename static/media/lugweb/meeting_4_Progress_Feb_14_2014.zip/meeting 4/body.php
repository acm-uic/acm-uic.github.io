<div id="centermsg">
	<h1>SIG Web Meeting #3</h1>
	<h2>A short introduction to Server-side Development</h2>
	<p>On the contrary to the previous two weeks, this is certainly a better effort toward better design.</p>
</div>
<?php
	if ($result = $mysqli->query("SELECT * FROM posts")) {
		$numresults = $result->num_rows;
	}

?>
<article>
	<?php printf ("The number of results is: %d", $numresults);?>
	<header><h1>Results:</h1></header>
	<table>
		<tr><th>ID</th><th>Title</th><th>Body</th><th>Time</th><th>Actions</th></tr>
<?php		
	while ($current = $result->fetch_object()) {
		printf ("<tr><td>%d</td><td>%s</td><td>%s</td><td>%s</td><td><a href='view.php?id=%s'>View</a> | <a href='edit.php?id=%s'>Edit</a> | Delete</td></tr>", $current->id, $current->title, $current->body, $current->timestamp, $current->id, $current->id);
	}
	if ($numresults == 0) {
		echo "<tr><td></td><td>Nothing to display...</td><td></td><td></td><td></td></tr>";
	}
?>
	</table>
</article>
