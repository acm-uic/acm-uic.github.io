<?php

$mysqli = new mysqli("localhost", "testuser", "password", "sigwebtest");

if ($mysqli->connect_errno) {
	printf("Oh noes.... There is an error! :-(");
	die();
}
